
package com.uaemex.fiuaemex.dto;


public class ConsumeOrProduceLongStringDto {
    private long key;
    private String value;

    public long getKey() {
        return key;
    }

    public void setKey(long key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

   
    
    
}
