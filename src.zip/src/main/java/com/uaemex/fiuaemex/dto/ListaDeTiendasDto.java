
package com.uaemex.fiuaemex.dto;


public class ListaDeTiendasDto {
    
}
