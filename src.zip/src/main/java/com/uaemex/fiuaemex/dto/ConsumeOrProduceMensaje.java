package com.uaemex.fiuaemex.dto;


public class ConsumeOrProduceMensaje {
    private String mensaje;

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
}
