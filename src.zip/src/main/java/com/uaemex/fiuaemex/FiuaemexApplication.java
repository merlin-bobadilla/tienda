package com.uaemex.fiuaemex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiuaemexApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiuaemexApplication.class, args);
	}

}
