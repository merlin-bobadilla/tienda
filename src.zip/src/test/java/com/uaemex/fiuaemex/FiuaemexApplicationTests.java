package com.uaemex.fiuaemex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiuaemexApplicationTests {

	@Test
	void contextLoads() {
	}

}
